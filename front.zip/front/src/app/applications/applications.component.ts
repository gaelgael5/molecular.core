
import {Component} from '@angular/core';

@Component({
    selector:"applications",
    styleUrls: ['./applications.component.css'],
    templateUrl: './applications.component.html'
})
export class Applications {

    constructor() {
        
    }


}
