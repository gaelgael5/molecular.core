// import { ITreeNode } from "angular-tree-component/dist/defs/api";
// import { TreeNode } from "angular-tree-component";



// export class tree implements ITreeNode {

//     parent: ITreeNode;
//     displayField: string;
//     children: ITreeNode[];
//     data: any;
//     elementRef: any;
//     level: number;
//     path: string[];
//     index: number;
//     id: string | number;
//     isExpanded: boolean;
//     isActive: boolean;
//     isFocused: boolean;
//     isCollapsed: boolean;
//     isLeaf: boolean;
//     hasChildren: boolean;
//     isRoot: boolean;

//     findNextSibling(skipHidden: any): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     findPreviousSibling(skipHidden: any): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     getFirstChild(skipHidden: any): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     getLastChild(skipHidden: any): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     findNextNode(goInside: boolean): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     findPreviousNode(skipHidden: any): ITreeNode {
//         throw new Error("Method not implemented.");
//     }
//     isDescendantOf(node: ITreeNode): boolean {
//         throw new Error("Method not implemented.");
//     }
//     getNodePadding(): string {
//         throw new Error("Method not implemented.");
//     }
//     getClass(): string {
//         throw new Error("Method not implemented.");
//     }
//     toggleExpanded() {
//         throw new Error("Method not implemented.");
//     }
//     expand() {
//         throw new Error("Method not implemented.");
//     }
//     collapse() {
//         throw new Error("Method not implemented.");
//     }
//     ensureVisible() {
//         throw new Error("Method not implemented.");
//     }
//     toggleActivated(multi: any) {
//         throw new Error("Method not implemented.");
//     }
//     focus() {
//         throw new Error("Method not implemented.");
//     }
//     blur() {
//         throw new Error("Method not implemented.");
//     }
//     hide() {
//         throw new Error("Method not implemented.");
//     }
//     show() {
//         throw new Error("Method not implemented.");
//     }
//     setIsHidden(value: boolean) {
//         throw new Error("Method not implemented.");
//     }
//     scrollIntoView() {
//         throw new Error("Method not implemented.");
//     }
//     fireEvent(event: any) {
//         throw new Error("Method not implemented.");
//     }
//     doForAll(fn: (node: ITreeNode) => ) {
//         throw new Error("Method not implemented.");
//     }
//     expandAll() {
//         throw new Error("Method not implemented.");
//     }
//     collapseAll() {
//         throw new Error("Method not implemented.");
//     }

// }