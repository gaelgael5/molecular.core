

export enum RibbonFormatSizeEnum {
    
        List = 0,
        Small = 1,
        Normal = 2
    }
    